# LCMarathoner
**infinite stamina**
<figure>
  <img src="https://cdn.stealthoptional.com/images/ncavvykf/stealth/f57722f711dc7b4b2fff9398e1764ec5974a5186-1920x1080.jpg?rect=0,36,1920,1008&w=1200&h=630&auto=format">
</figure>
